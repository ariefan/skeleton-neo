-- MySQL dump 10.13  Distrib 9.6.0, for Win64 (x86_64)
--
-- Host: localhost    Database: simpbb_neo
-- ------------------------------------------------------
-- Server version	9.6.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ 'b986f1f8-1dcc-11f1-a0a4-4c445b352757:1-142';

--
-- Table structure for table `__drizzle_migrations`
--

DROP TABLE IF EXISTS `__drizzle_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `__drizzle_migrations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `hash` text NOT NULL,
  `created_at` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `__drizzle_migrations`
--

LOCK TABLES `__drizzle_migrations` WRITE;
/*!40000 ALTER TABLE `__drizzle_migrations` DISABLE KEYS */;
/*!40000 ALTER TABLE `__drizzle_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account` (
  `id` varchar(36) NOT NULL,
  `account_id` text NOT NULL,
  `provider_id` text NOT NULL,
  `user_id` varchar(36) NOT NULL,
  `access_token` text,
  `refresh_token` text,
  `id_token` text,
  `access_token_expires_at` timestamp(3) NULL DEFAULT NULL,
  `refresh_token_expires_at` timestamp(3) NULL DEFAULT NULL,
  `scope` text,
  `password` text,
  `created_at` timestamp(3) NOT NULL DEFAULT (now()),
  `updated_at` timestamp(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `account_userId_idx` (`user_id`),
  CONSTRAINT `account_user_id_user_id_fk` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account`
--

LOCK TABLES `account` WRITE;
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
INSERT INTO `account` VALUES ('QbBajLpGGYU9128QaVb2IEuFwUPG7dxs','105810459324349693423','google','ZYdiaL1m7Qxglg54m2adbjXAVR1B4p9y','ya29.a0ATkoCc6zuDpaw9ZMI73-WE4seUEz3upZSe6C6S1BQ2apjfYd8PPYc_Gu-nj81zXpXG__PDV3VQ7gmpnxD8XfmqKSCqsIDJx2IEdeMmiJuySWKdppjGs5Uk3p23RoVv0QewXCw2oVcEb41jZgS8wXwaQnjP1T0ecPy-MJQ5fOjzVX39IycsOR5wZHJmc-D8-CyrAsX0AaCgYKAeQSARcSFQHGX2MigqaZbPg6FijkRuyPfa0cLg0206',NULL,'eyJhbGciOiJSUzI1NiIsImtpZCI6IjUzMDcyNGQ0OTE3M2EzZWQ2YjRhMDBhYTYzNDQyMDMwMGQ3MmFlNWIiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJhenAiOiIxMDQwNTAzOTk5MTAzLXZta210MDgydG10Y2ZnOXJlYnNkdWo1cHZ1cDM2a25vLmFwcHMuZ29vZ2xldXNlcmNvbnRlbnQuY29tIiwiYXVkIjoiMTA0MDUwMzk5OTEwMy12bWttdDA4MnRtdGNmZzlyZWJzZHVqNXB2dXAzNmtuby5hcHBzLmdvb2dsZXVzZXJjb250ZW50LmNvbSIsInN1YiI6IjEwNTgxMDQ1OTMyNDM0OTY5MzQyMyIsImVtYWlsIjoidGVjaG5vc21hcnRtQGdtYWlsLmNvbSIsImVtYWlsX3ZlcmlmaWVkIjp0cnVlLCJhdF9oYXNoIjoiMFA2MGRHQXlfVHdReW1tMTVPd1lVQSIsIm5hbWUiOiJUZWNobm9zbWFydCBNZWRpYSIsInBpY3R1cmUiOiJodHRwczovL2xoMy5nb29nbGV1c2VyY29udGVudC5jb20vYS9BQ2c4b2NMTGNoWVVqa0VIUHk5ZDJ6dE9QeVVVSVUySF9hZTB3dTRGRmlRSkd0UVRNRTFaTGRVPXM5Ni1jIiwiZ2l2ZW5fbmFtZSI6IlRlY2hub3NtYXJ0IiwiZmFtaWx5X25hbWUiOiJNZWRpYSIsImlhdCI6MTc3MzM1OTQyOCwiZXhwIjoxNzczMzYzMDI4fQ.dZTDUsYDi8Tu8WzzaNSRAPZ6EvuyuzHaHqnxqxHJ1yRW0e4XJqRHLXUADvq4rZvMTB5jOqmCVR-WluFkC1hyxi434e0TpEueEk5rv-YQxDDt9zJD39q5-OdO-XDZ488v8freuV_66MXzpRHgIMCvtki7uiP8QSkkaOYKZnaNaYASR76iIF5wk9-K931buVIDm-gdooi8IKFv4nhTIYsys4QU0fUDQ_oMktDw7wkwPc78zvLiC_d1fHMHIed7RAX00yNguC3RqieY4Q-i6uLLwBXgm6yEscgRdsqRG6dlPRjY330cDSWMLTX3TR7TDcQ_DhZv-g16Upion8pTm5InFQ','2026-03-12 17:50:28.129',NULL,'https://www.googleapis.com/auth/userinfo.profile,openid,https://www.googleapis.com/auth/userinfo.email',NULL,'2026-03-12 16:50:29.156','2026-03-12 16:50:29.156');
/*!40000 ALTER TABLE `account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `books`
--

DROP TABLE IF EXISTS `books`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `books` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `published_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT (now()),
  `updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
  `cover_image` varchar(512) DEFAULT NULL,
  `attachment_file` varchar(512) DEFAULT NULL,
  `gallery_images` json DEFAULT NULL,
  `additional_documents` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `books`
--

LOCK TABLES `books` WRITE;
/*!40000 ALTER TABLE `books` DISABLE KEYS */;
INSERT INTO `books` VALUES (1,'wertry','wteyry','2026-03-04 17:00:00','2026-03-13 16:04:57','2026-03-13 16:04:57',NULL,NULL,NULL,NULL),(2,'tyukil','tryui','2026-03-10 17:00:00','2026-03-14 00:46:04','2026-03-13 17:47:56','files/7d62d0ef-5798-4524-9603-a004d0fa03f6.png','files/68b37db0-ad71-4e47-ab95-8ec5213c0a95.pdf','[\"files/f616d5bf-988a-4f37-a7b7-420a1a827d3a.jpg\", \"files/bbcc4f01-ce8d-4e8f-8ace-7b871fcc3047.jpg\"]','[\"files/0ffb33ca-080e-4e2c-8e7b-931efd76d742.pdf\", \"files/a52bf354-9cf3-45a4-ab75-9a96f6c9ebda.pdf\", \"files/a91cce75-18a1-44ff-bd84-1c88fffc8b6a.pdf\"]');
/*!40000 ALTER TABLE `books` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invitation`
--

DROP TABLE IF EXISTS `invitation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `invitation` (
  `id` varchar(36) NOT NULL,
  `organization_id` varchar(36) NOT NULL,
  `email` varchar(255) NOT NULL,
  `role` varchar(255) DEFAULT NULL,
  `team_id` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'pending',
  `expires_at` timestamp(3) NOT NULL,
  `created_at` timestamp(3) NOT NULL DEFAULT (now()),
  `inviter_id` varchar(36) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `invitation_inviter_id_user_id_fk` (`inviter_id`),
  KEY `invitation_organizationId_idx` (`organization_id`),
  KEY `invitation_email_idx` (`email`),
  CONSTRAINT `invitation_inviter_id_user_id_fk` FOREIGN KEY (`inviter_id`) REFERENCES `user` (`id`) ON DELETE CASCADE,
  CONSTRAINT `invitation_organization_id_organization_id_fk` FOREIGN KEY (`organization_id`) REFERENCES `organization` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invitation`
--

LOCK TABLES `invitation` WRITE;
/*!40000 ALTER TABLE `invitation` DISABLE KEYS */;
/*!40000 ALTER TABLE `invitation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member` (
  `id` varchar(36) NOT NULL,
  `organization_id` varchar(36) NOT NULL,
  `user_id` varchar(36) NOT NULL,
  `role` varchar(255) NOT NULL DEFAULT 'member',
  `created_at` timestamp(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `member_organizationId_idx` (`organization_id`),
  KEY `member_userId_idx` (`user_id`),
  CONSTRAINT `member_organization_id_organization_id_fk` FOREIGN KEY (`organization_id`) REFERENCES `organization` (`id`) ON DELETE CASCADE,
  CONSTRAINT `member_user_id_user_id_fk` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification_preferences`
--

DROP TABLE IF EXISTS `notification_preferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification_preferences` (
  `id` varchar(36) NOT NULL,
  `user_id` varchar(36) NOT NULL,
  `in_app_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `toasts_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `success_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `warning_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `error_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `info_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `notification_preferences_userId_idx` (`user_id`),
  CONSTRAINT `notification_preferences_user_id_user_id_fk` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_preferences`
--

LOCK TABLES `notification_preferences` WRITE;
/*!40000 ALTER TABLE `notification_preferences` DISABLE KEYS */;
/*!40000 ALTER TABLE `notification_preferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` varchar(36) NOT NULL,
  `user_id` varchar(36) NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `type` varchar(50) NOT NULL DEFAULT 'info',
  `link` text,
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`),
  KEY `notifications_userId_idx` (`user_id`),
  KEY `notifications_createdAt_idx` (`created_at`),
  CONSTRAINT `notifications_user_id_user_id_fk` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES ('3db2d860-f871-424d-919d-8dfbd10494f3','ZYdiaL1m7Qxglg54m2adbjXAVR1B4p9y','Real-time Test Alert','This successful test notification was triggered via oRPC! SSE is working beautifully using native Next.js 16 WebStreams.','success',NULL,1,'2026-03-19 08:12:28'),('5bed3fe6-85c8-4fb8-8c04-7710bdacd760','ZYdiaL1m7Qxglg54m2adbjXAVR1B4p9y','Real-time Test Alert','This successful test notification was triggered via oRPC! SSE is working beautifully using native Next.js 16 WebStreams.','success',NULL,1,'2026-03-19 08:10:51'),('941ed808-3e44-4ef9-b27e-5346198d682b','ZYdiaL1m7Qxglg54m2adbjXAVR1B4p9y','Real-time Test Alert','This successful test notification was triggered via oRPC! SSE is working beautifully using native Next.js 16 WebStreams.','success',NULL,1,'2026-03-19 08:11:05');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_access_token`
--

DROP TABLE IF EXISTS `oauth_access_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_access_token` (
  `id` varchar(36) NOT NULL,
  `access_token` varchar(255) DEFAULT NULL,
  `refresh_token` varchar(255) DEFAULT NULL,
  `access_token_expires_at` timestamp(3) NULL DEFAULT NULL,
  `refresh_token_expires_at` timestamp(3) NULL DEFAULT NULL,
  `client_id` varchar(36) DEFAULT NULL,
  `user_id` varchar(36) DEFAULT NULL,
  `scopes` text,
  `created_at` timestamp(3) NULL DEFAULT NULL,
  `updated_at` timestamp(3) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `oauth_access_token_access_token_unique` (`access_token`),
  UNIQUE KEY `oauth_access_token_refresh_token_unique` (`refresh_token`),
  KEY `oauthAccessToken_clientId_idx` (`client_id`),
  KEY `oauthAccessToken_userId_idx` (`user_id`),
  CONSTRAINT `oauth_access_token_client_id_oauth_application_client_id_fk` FOREIGN KEY (`client_id`) REFERENCES `oauth_application` (`client_id`) ON DELETE CASCADE,
  CONSTRAINT `oauth_access_token_user_id_user_id_fk` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_access_token`
--

LOCK TABLES `oauth_access_token` WRITE;
/*!40000 ALTER TABLE `oauth_access_token` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_access_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_application`
--

DROP TABLE IF EXISTS `oauth_application`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_application` (
  `id` varchar(36) NOT NULL,
  `name` text,
  `icon` text,
  `metadata` text,
  `client_id` varchar(255) DEFAULT NULL,
  `client_secret` text,
  `redirect_urls` text,
  `type` text,
  `disabled` tinyint(1) DEFAULT '0',
  `user_id` varchar(36) DEFAULT NULL,
  `created_at` timestamp(3) NULL DEFAULT NULL,
  `updated_at` timestamp(3) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `oauth_application_client_id_unique` (`client_id`),
  KEY `oauthApplication_userId_idx` (`user_id`),
  CONSTRAINT `oauth_application_user_id_user_id_fk` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_application`
--

LOCK TABLES `oauth_application` WRITE;
/*!40000 ALTER TABLE `oauth_application` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_application` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_consent`
--

DROP TABLE IF EXISTS `oauth_consent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_consent` (
  `id` varchar(36) NOT NULL,
  `client_id` varchar(36) DEFAULT NULL,
  `user_id` varchar(36) DEFAULT NULL,
  `scopes` text,
  `created_at` timestamp(3) NULL DEFAULT NULL,
  `updated_at` timestamp(3) NULL DEFAULT NULL,
  `consent_given` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauthConsent_clientId_idx` (`client_id`),
  KEY `oauthConsent_userId_idx` (`user_id`),
  CONSTRAINT `oauth_consent_client_id_oauth_application_client_id_fk` FOREIGN KEY (`client_id`) REFERENCES `oauth_application` (`client_id`) ON DELETE CASCADE,
  CONSTRAINT `oauth_consent_user_id_user_id_fk` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_consent`
--

LOCK TABLES `oauth_consent` WRITE;
/*!40000 ALTER TABLE `oauth_consent` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_consent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `organization`
--

DROP TABLE IF EXISTS `organization`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `organization` (
  `id` varchar(36) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `logo` text,
  `created_at` timestamp(3) NOT NULL,
  `metadata` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `organization_slug_unique` (`slug`),
  UNIQUE KEY `organization_slug_uidx` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organization`
--

LOCK TABLES `organization` WRITE;
/*!40000 ALTER TABLE `organization` DISABLE KEYS */;
/*!40000 ALTER TABLE `organization` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `session`
--

DROP TABLE IF EXISTS `session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `session` (
  `id` varchar(36) NOT NULL,
  `expires_at` timestamp(3) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp(3) NOT NULL DEFAULT (now()),
  `updated_at` timestamp(3) NOT NULL,
  `ip_address` text,
  `user_agent` text,
  `user_id` varchar(36) NOT NULL,
  `impersonated_by` text,
  `active_organization_id` text,
  `active_team_id` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `session_token_unique` (`token`),
  KEY `session_userId_idx` (`user_id`),
  CONSTRAINT `session_user_id_user_id_fk` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `session`
--

LOCK TABLES `session` WRITE;
/*!40000 ALTER TABLE `session` DISABLE KEYS */;
INSERT INTO `session` VALUES ('7784IrphNzNYF7PUYIISbapLIomtnEbx','2026-03-26 08:10:06.323','XMnuyCUZjPwD9N42LrKyLNbLiJCpkMqA','2026-03-12 16:50:29.164','2026-03-19 08:10:06.323','0000:0000:0000:0000:0000:0000:0000:0000','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','ZYdiaL1m7Qxglg54m2adbjXAVR1B4p9y',NULL,NULL,NULL);
/*!40000 ALTER TABLE `session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team`
--

DROP TABLE IF EXISTS `team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `team` (
  `id` varchar(36) NOT NULL,
  `name` text NOT NULL,
  `organization_id` varchar(36) NOT NULL,
  `created_at` timestamp(3) NOT NULL,
  `updated_at` timestamp(3) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `team_organizationId_idx` (`organization_id`),
  CONSTRAINT `team_organization_id_organization_id_fk` FOREIGN KEY (`organization_id`) REFERENCES `organization` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team`
--

LOCK TABLES `team` WRITE;
/*!40000 ALTER TABLE `team` DISABLE KEYS */;
/*!40000 ALTER TABLE `team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team_member`
--

DROP TABLE IF EXISTS `team_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `team_member` (
  `id` varchar(36) NOT NULL,
  `team_id` varchar(36) NOT NULL,
  `user_id` varchar(36) NOT NULL,
  `created_at` timestamp(3) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `teamMember_teamId_idx` (`team_id`),
  KEY `teamMember_userId_idx` (`user_id`),
  CONSTRAINT `team_member_team_id_team_id_fk` FOREIGN KEY (`team_id`) REFERENCES `team` (`id`) ON DELETE CASCADE,
  CONSTRAINT `team_member_user_id_user_id_fk` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team_member`
--

LOCK TABLES `team_member` WRITE;
/*!40000 ALTER TABLE `team_member` DISABLE KEYS */;
/*!40000 ALTER TABLE `team_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `two_factor`
--

DROP TABLE IF EXISTS `two_factor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `two_factor` (
  `id` varchar(36) NOT NULL,
  `secret` varchar(255) NOT NULL,
  `backup_codes` text NOT NULL,
  `user_id` varchar(36) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `twoFactor_secret_idx` (`secret`),
  KEY `twoFactor_userId_idx` (`user_id`),
  CONSTRAINT `two_factor_user_id_user_id_fk` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `two_factor`
--

LOCK TABLES `two_factor` WRITE;
/*!40000 ALTER TABLE `two_factor` DISABLE KEYS */;
/*!40000 ALTER TABLE `two_factor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` varchar(36) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified` tinyint(1) NOT NULL DEFAULT '0',
  `image` text,
  `created_at` timestamp(3) NOT NULL DEFAULT (now()),
  `updated_at` timestamp(3) NOT NULL DEFAULT (now()),
  `two_factor_enabled` tinyint(1) DEFAULT '0',
  `username` varchar(255) DEFAULT NULL,
  `display_username` text,
  `phone_number` varchar(255) DEFAULT NULL,
  `phone_number_verified` tinyint(1) DEFAULT NULL,
  `role` text,
  `banned` tinyint(1) DEFAULT '0',
  `ban_reason` text,
  `ban_expires` timestamp(3) NULL DEFAULT NULL,
  `is_anonymous` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_email_unique` (`email`),
  UNIQUE KEY `user_username_unique` (`username`),
  UNIQUE KEY `user_phone_number_unique` (`phone_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES ('ZYdiaL1m7Qxglg54m2adbjXAVR1B4p9y','Technosmart Media','technosmartm@gmail.com',1,'https://lh3.googleusercontent.com/a/ACg8ocLLchYUjkEHPy9d2ztOPyUUIU2H_ae0wu4FFiQJGtQTME1ZLdU=s96-c','2026-03-12 16:50:29.149','2026-03-12 16:50:29.149',0,NULL,NULL,NULL,NULL,'user',0,NULL,NULL,0);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `verification`
--

DROP TABLE IF EXISTS `verification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `verification` (
  `id` varchar(36) NOT NULL,
  `identifier` varchar(255) NOT NULL,
  `value` text NOT NULL,
  `expires_at` timestamp(3) NOT NULL,
  `created_at` timestamp(3) NOT NULL DEFAULT (now()),
  `updated_at` timestamp(3) NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`),
  KEY `verification_identifier_idx` (`identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `verification`
--

LOCK TABLES `verification` WRITE;
/*!40000 ALTER TABLE `verification` DISABLE KEYS */;
INSERT INTO `verification` VALUES ('HEyDSdJR8wkV4wxtH5vuI7nGy3S1zaWY','f1qgP87UPtxh1sMJeutob9I5x4k8bXsQ','{\"callbackURL\":\"/dashboard\",\"codeVerifier\":\"mCseBrZZVnl-zpvnHX4jrBbeltMrWKE1HEt5dXnp5ncxVDDvsqDeCRI_CxalV8dDUksy4cqRuCXqECzcOx4knp-1SLjWXdksINwFcMfOUcqaY0-E0W6a65Hkjgr9oZc1\",\"expiresAt\":1773359998378}','2026-03-12 16:59:58.386','2026-03-12 16:49:58.386','2026-03-12 16:49:58.386');
/*!40000 ALTER TABLE `verification` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-20  0:58:34
